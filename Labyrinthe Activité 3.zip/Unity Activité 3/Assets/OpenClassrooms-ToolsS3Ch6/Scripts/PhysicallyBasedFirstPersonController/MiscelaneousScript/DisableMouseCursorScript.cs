﻿using UnityEngine;
using System.Collections;

public class DisableMouseCursorScript : MonoBehaviour {

	void Start()
	{
		Screen.showCursor = false;
	}
}
